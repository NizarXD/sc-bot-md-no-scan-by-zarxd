/*
   Script By DidinPedia
   Ad keperluan? chat wa : 6289518363262
   🌹 Subscribe : DidinPedia 🌹
*/

const fs = require('fs')
const chalk = require('chalk')

/* ~~~~~~~~~ WEB API ~~~~~~~~~ */
global.lol = '087b203a426c96a19fba8578' // https://api.lolhuman.xyz
global.xzn = '' // https://xnz.wtf
global.din = 'fff18d97'
/* ~~~~~~~~~ SETTINGS OWNER ~~~~~~~~~ */
global.numberowner = '62895328709048' // Owner Utama
global.owner = ['62895328709048', '62895328709048'] // Owner Lainnya
global.namaowner = 'Zarxd bot ダ' // Nama Owner
global.premium = ["62895328709048"] // Premium User
global.nobot = '62895328709048'
global.ownername = 'Zarxd boy ダ' //ubah jadi nama mu, note tanda ' gausah di hapus!
global.domain = '' // Isi Domain Lu
global.apikey2 = '' // Isi Apikey Plta Lu
global.keyopenai = "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"
global.capikey2 = '' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.themeemoji = '•'
//MAU PEDIA
global.api_key = "YSZPjCashPmRite9lhO8cPg9JSSR8vJVXLL43neqr0REh0oDx84l7VyZkpfIxoDW"//@zallDev
global.api_id = "KgxIfJexaB4vJLTl"//@zallDev
global.secret = "didin"//@zallDev
/* ------------------- GLOBAL E - WALLET / PEMBAYARAN ------ */
global.dana = "gak ada"
global.gopay = "Gak ada"
global.ovo = "gak ada"
/* ~~~~~~~~~ SETTINGS BOT ~~~~~~~~~ */
global.namabot = 'Zarxd bot' // NickBot
global.typemenu = 'v2' // 'v1' > 'v2' > 'v3' > 'v4'
global.typereply = 'v1' // 'v1' > 'v2'
global.autoread = false // ReadChat
global.autobio = false // AutoBio
global.autoblok212 = true // AutoBlock Nomer +212
global.onlyindo = false  // AutoBlock Selain Nomer Indo
global.packname = 'By @Zarxd' // Watermark Sticker
global.author = 'Zarxd bot ダ' // Watermark Sticker
/* ~~~~~~~~~ MESSAGES ~~~~~~~~~ */
/* -------- BATAS ------- */
global.mess = {
    done: 'sᴜᴅᴀʜ ᴋᴀᴋ !!',
    prem: 'Feature Only For User _*PREMIUM*_',
    admin: 'ɪɴɪ ᴋʜᴜsᴜs ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ ᴋᴀᴋ, ᴇᴍᴀɴɢ ʟᴜ sɪᴀᴘᴀ ᴀɴᴊᴇɴɢ ?',
    botAdmin: 'Perintah Ini Hanya Bisa Digunakan Ketika Bot Menjadi Admin Group !',
    owner: '*ᴡᴀᴅᴜʜ ᴋᴀᴋ ɪɴɪ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ ʜᴇʜᴇ !*',
    group: '*ᴋʜᴜsᴜs ᴅɪ ɢʀᴏᴜᴘ ᴋᴀᴋᴀ.*',
    private: '*ғɪᴛᴜʀ ɪɴɪ ʙɪsᴀ ᴅɪ ɢᴜɴᴀᴋᴀɴ ᴅɪ ᴄʜᴀᴛ ᴘʀɪʙᴀᴅɪ ᴋᴀᴋ.*',
    wait: '*ᴛᴜɴɢɢᴜ sᴇʙᴇɴᴛᴀʀ ʏᴀ ᴋᴀᴋ ʟᴀɢɪ ᴅɪ ᴘʀᴏsᴇs !*',    
    error: '_*Sorry Features Error*_',
}
/* ~~~~~~~~~ THUMBNAIL ~~~~~~~~~ */
global.thumb = fs.readFileSync('./didin/media/quoted.jpg')
global.menu = fs.readFileSync('./didin/media/menu.jpg')
/* ~~~~~~~~~ EDITS LINK ~~~~~~~~~ */
global.link = 'https://chat.whatsapp.com/JQQRMoXEHpiEHd9KLMEzuC'
global.wagc = 'https://chat.whatsapp.com/JQQRMoXEHpiEHd9KLMEzuC'
/* ~~~~~~~~~ END SYSTEM ~~~~~~~~~ */
let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})
